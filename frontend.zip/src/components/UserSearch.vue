<template>
  <div>
    <div>
      <DxTextBox v-model="username"></DxTextBox>
      <DxButton text="검색" width="100" @click="onSearch"></DxButton>
    </div>
    <div>
      <DxDataGrid
        ref="dataGrid"
        :data-source="dataSource"
        :show-borders="true"
        :show-row-lines="true"
        :row-alternation-enabled="false"
        :selection="{ mode: 'single' }"
      >
        <DxSelection select-all-mode="allPages" mode="multiple"></DxSelection>
        <DxColumn data-field="username"></DxColumn>
        <DxColumn data-field="grade"></DxColumn>
        <DxColumn data-field="deptname"></DxColumn>
        <DxColumn data-field="company"></DxColumn>
        <DxColumn data-field="cellno"></DxColumn>
        <DxColumn data-field="email"></DxColumn>
        <DxColumn data-field="status"></DxColumn>
      </DxDataGrid>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

import { DxButton } from "devextreme-vue/button";
import { DxDataGrid, DxColumn, DxSelection } from "devextreme-vue/data-grid";
import { DxTextBox } from "devextreme-vue/text-box";

import AbstractView from "../views/AbstractView.vue";

@Component({
  components: {
    DxButton,
    DxDataGrid,
    DxColumn,
    DxSelection,
    DxTextBox,
  },
})
export default class UserSearch extends AbstractView {
  private username = "";

  constructor() {
    super();
  }

  public mounted() {
    console.log("mounted...");
  }

  public get dataGrid() {
    return (this.$refs["dataGrid"] as any).instance;
  }

  public get dataSource() {
    return [
      {
        username: "홍길동1",
        grade: "대리",
        deptname: "전략사업부",
        company: "좋은회사",
        cellno: "010-1234-5678",
        email: "gdhong1@gmail.com",
        status: "재직",
      },
      {
        username: "홍길동2",
        grade: "대리",
        deptname: "전략사업부",
        company: "좋은회사",
        cellno: "010-1234-5678",
        email: "gdhong1@gmail.com",
        status: "재직",
      },
      {
        username: "홍길동3",
        grade: "대리",
        deptname: "전략사업부",
        company: "좋은회사",
        cellno: "010-1234-5678",
        email: "gdhong1@gmail.com",
        status: "재직",
      },
      {
        username: "홍길동4",
        grade: "대리",
        deptname: "전략사업부",
        company: "좋은회사",
        cellno: "010-1234-5678",
        email: "gdhong1@gmail.com",
        status: "재직",
      },
      {
        username: "홍길동5",
        grade: "대리",
        deptname: "전략사업부",
        company: "좋은회사",
        cellno: "010-1234-5678",
        email: "gdhong1@gmail.com",
        status: "재직",
      },
    ];
  }

  public onSearch(e: any) {
    // super.isLoading(true);
    console.log("onSearch...", this.username);
  }
}
</script>
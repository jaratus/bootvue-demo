<template>
  <div @click="addCounter">{{ text }} was clicked {{ counter }} times</div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";

@Component
export default class MyItem extends Vue {
  @Prop() private text!: string;
  private counter = 0;

  public addCounter() {
    this.counter = this.counter + 1;
  }
}
</script>
<template>
  <DxList
    :width="250"
    selection-mode="single"
    :items="items"
    @selection-changed="navigate"
    item-template="links"
  >
    <template #links="{ data }">
      <div>
        <router-link :to="'/' + data.path">
          <div>
            <div class="dx-list-item-icon-container">
              <i
                class="dx-icon dx-list-item-icon"
                :class="'dx-icon-' + data.icon"
              ></i>
            </div>
            <span>{{ data.text }}</span>
          </div>
        </router-link>
      </div>
    </template>
  </DxList>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

import { DxList } from "devextreme-vue/list";

@Component({
  components: {
    DxList,
  },
})
export default class NavigationList extends Vue {
  private items: any[] = [];

  constructor() {
    super();
  }

  public mounted() {
    this.items = [
      { id: 1, text: "Inbox", icon: "message", path: "inbox" },
      { id: 2, text: "Sent Mail", icon: "check", path: "sent-mail" },
      { id: 3, text: "Trash", icon: "trash", path: "trash" },
      { id: 4, text: "spam", icon: "mention", path: "mention" },
    ];
  }

  public navigate(e: any) {
    console.log("navigate...", e);
    this.$emit("navigated", e);
  }
}
</script>
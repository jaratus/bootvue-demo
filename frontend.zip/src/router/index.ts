import Vue from "vue";
import VueRouter, { RouteConfig } from "vue-router";
import Home from "../views/Home.vue";

Vue.use(VueRouter);

const routes: Array<RouteConfig> = [
  {
    path: "/",
    name: "Home",
    component: Home,
  },
  {
    path: "/about",
    name: "About",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/About.vue"),
  },
  {
    path: "/firsttypescript",
    name: "FirstTypeScript",
    component: () =>
      import("../views/FirstTypeScript.vue"),
  },
  {
    path: "/simpledatagrid",
    name: "SimpleDataGrid",
    component: () =>
      import("../views/SimpleDataGrid.vue"),
  },
  {
    path: "/resourcescheduler",
    name: "ResourceScheduler",
    component: () =>
      import("../views/ResourceScheduler.vue"),
  },
  {
    path: "/usersearch",
    name: "사용자 조회",
    component: () =>
      import("../views/UserSearchList.vue"),
  },
  {
    path: "/mail",
    name: "Mail",
    component: () =>
      import("../views/MailList.vue"),
  },
  {
    path: "/approval",
    name: "Approval",
    component: () =>
      import("../views/ApprovalList.vue"),
  },
  {
    path: "/navigator",
    name: "Navigator",
    component: () =>
      import("../views/Navigator.vue"),
  },
  {
    path: "/inbox",
    name: "Inbox",
    component: () =>
      import("../views/Inbox.vue"),
  },
  {
    path: "/sent-mail",
    name: "Sent Mail",
    component: () =>
      import("../views/SentMail.vue"),
  },
  {
    path: "/trash",
    name: "Trash",
    component: () =>
      import("../views/Trash.vue"),
  },
  {
    path: "/mention",
    name: "Spam",
    component: () =>
      import("../views/Spam.vue"),
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;

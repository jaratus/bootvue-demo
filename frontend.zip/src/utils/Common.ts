/**
 * DevExtreme datagrid row merge method
 * 
 * @param mergels 
 * @param cinfo 
 * @param refnames 
 */
export function RowMerge(mergels: any, cinfo: any, refnames: string[]) {
  if (cinfo.rowType !== "data") return;
  if (cinfo.rowIndex > 0 && cinfo.column.command !== "edit") {
    let chkVal = "";
    let curVal = "";
    refnames.forEach((refname) => {
      chkVal += cinfo.component.cellValue(cinfo.rowIndex - 1, refname);
      curVal += cinfo.component.cellValue(cinfo.rowIndex, refname);
    });
    if (chkVal === curVal) {
      if (cinfo.component.cellValue(cinfo.rowIndex - 1, cinfo.column.dataField)) {
        const prev: any = mergels[cinfo.rowIndex - 1][cinfo.column.dataField];
        if (!mergels[cinfo.rowIndex]) mergels[cinfo.rowIndex] = {};
        mergels[cinfo.rowIndex][cinfo.column.dataField] = prev;
        if (prev) {
          cinfo.cellElement.style.display = "none";
          const span: number = prev.rowSpan;
          if (span) prev.rowSpan = span + 1;
          else prev.rowSpan = 2;
        }
      } else {
        if (!mergels[cinfo.rowIndex]) mergels[cinfo.rowIndex] = {};
        mergels[cinfo.rowIndex][cinfo.column.dataField] = cinfo.cellElement;
      }
    } else {
      if (!mergels[cinfo.rowIndex]) mergels[cinfo.rowIndex] = {};
      mergels[cinfo.rowIndex][cinfo.column.dataField] = cinfo.cellElement;
    }
  } else {
    if (!mergels[cinfo.rowIndex]) mergels[cinfo.rowIndex] = {};
    mergels[cinfo.rowIndex][cinfo.column.dataField] = cinfo.cellElement;
  }
};
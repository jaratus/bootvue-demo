<template>
  <div>
    <DxLoadPanel
      :visible="loading"
      :show-indicator="true"
      :show-pane="true"
      :shading="true"
      :close-on-outside-click="false"
      shading-color="rgba(0,0,0,0.4)"
      message="Please, wait..."
    ></DxLoadPanel>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

import { DxLoadPanel } from "devextreme-vue/load-panel";

@Component({
  components: {
    DxLoadPanel,
  },
})
export default class AbstractView extends Vue {
  private loading = false;

  constructor() {
    super();
  }

  public get isLoading() {
    return this.loading;
  }

  public set isLoading(loading: boolean) {
    this.loading = loading;
  }
}
</script>
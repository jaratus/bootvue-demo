<template>
  <div>
    <DxButton text="Mail" @click="onPopup"></DxButton>

    <DxPopup
      title="Mail"
      :visible="isPopupVisible"
      :close-on-outside-click="true"
      @hiding="
        () => {
          isPopupVisible = false;
        }
      "
    >
      <DxBox direction="row" width="100%">
        <DxBoxItem :ratio="0" base-size="150">
          <template #default>
            <div class="rect demo-dark">수신인</div>
          </template>
        </DxBoxItem>
        <DxBoxItem :ratio="1">
          <template #default>
            <div>
              <DxTextBox></DxTextBox>
            </div>
          </template>
        </DxBoxItem>
        <DxBoxItem :ratio="1" align="center">
          <template #default>
            <div>
              <DxButton text="검색" width="100"></DxButton>
            </div>
          </template>
        </DxBoxItem>
        <DxBoxItem :ratio="1">
          <template #default>
            <div style="padding-top: 10px">
              <DxRadioGroup
                :data-source="gubunSource"
                :value="gubun"
                layout="horizontal"
                @value-changed="gubunValueChanged"
              ></DxRadioGroup>
            </div>
          </template>
        </DxBoxItem>
      </DxBox>
      <br />
      <DxBox :height="200" direction="row" width="100%">
        <DxBoxItem :ratio="0" base-size="150">
          <template #default>
            <div class="rect demo-dark"></div>
          </template>
        </DxBoxItem>
        <DxBoxItem :ratio="1">
          <template #default>
            <div>
              <DxDataGrid
                ref="dataGrid"
                :height="200"
                :data-source="dataSource"
                :show-borders="true"
                :show-row-lines="true"
                :row-alternation-enabled="false"
                :selection="{ mode: 'single' }"
              >
                <DxColumn data-field="no" caption="순번" width="120"></DxColumn>
                <DxColumn
                  data-field="gubun"
                  caption="구분"
                  width="120"
                ></DxColumn>
                <DxColumn data-field="name" caption="성명"></DxColumn>
                <DxColumn data-field="grade" caption="직급"></DxColumn>
                <DxColumn data-field="dept" caption="부서"></DxColumn>
              </DxDataGrid>
            </div>
          </template>
        </DxBoxItem>
        <DxBoxItem :ratio="0" base-size="100">
          <template #default>
            <div style="margin-left: 5px">
              <DxButton text="삭제" @click="onDelete"></DxButton>
              <DxButton text="위로" @click="onUp"></DxButton>
              <DxButton text="아래로" @click="onDown"></DxButton>
            </div>
          </template>
        </DxBoxItem>
      </DxBox>
      <br />
      <DxBox direction="row" width="100%">
        <DxBoxItem :ratio="0" base-size="150">
          <template #default>
            <div class="rect demo-dark">제목</div>
          </template>
        </DxBoxItem>
        <DxBoxItem :ratio="1">
          <template #default>
            <div>
              <DxTextBox :value="subject"></DxTextBox>
            </div>
          </template>
        </DxBoxItem>
      </DxBox>
      <br />
      <DxBox :height="200" direction="row" width="100%">
        <DxBoxItem :ratio="0" base-size="150">
          <template #default>
            <div class="rect demo-dark">내용</div>
          </template>
        </DxBoxItem>
        <DxBoxItem :ratio="1">
          <template #default>
            <div>
              <DxHtmlEditor height="200" :value="contents">
                <DxMediaResizing :enabled="true" />
                <DxToolbar :multiline="false">
                  <DxItem name="undo" />
                  <DxItem name="redo" />
                  <DxItem name="separator" />
                  <!-- <DxItem :accepted-values="sizeValues" name="size" /> -->
                  <!-- <DxItem :accepted-values="fontValues" name="font" /> -->
                  <DxItem name="separator" />
                  <DxItem name="bold" />
                  <DxItem name="italic" />
                  <DxItem name="strike" />
                  <DxItem name="underline" />
                  <DxItem name="separator" />
                  <DxItem name="alignLeft" />
                  <DxItem name="alignCenter" />
                  <DxItem name="alignRight" />
                  <DxItem name="alignJustify" />
                  <DxItem name="separator" />
                  <DxItem name="orderedList" />
                  <DxItem name="bulletList" />
                  <DxItem name="separator" />
                  <!-- <DxItem :accepted-values="headerValues" name="header" /> -->
                  <DxItem name="separator" />
                  <DxItem name="color" />
                  <DxItem name="background" />
                  <DxItem name="separator" />
                  <DxItem name="link" />
                  <DxItem name="image" />
                  <DxItem name="separator" />
                  <DxItem name="clear" />
                  <DxItem name="codeBlock" />
                  <DxItem name="blockquote" />
                  <DxItem name="separator" />
                  <DxItem name="insertTable" />
                  <DxItem name="deleteTable" />
                  <DxItem name="insertRowAbove" />
                  <DxItem name="insertRowBelow" />
                  <DxItem name="deleteRow" />
                  <DxItem name="insertColumnLeft" />
                  <DxItem name="insertColumnRight" />
                  <DxItem name="deleteColumn" />
                </DxToolbar>
              </DxHtmlEditor>
            </div>
          </template>
        </DxBoxItem>
      </DxBox>
      <br />
      <DxBox :height="75" direction="row" width="100%">
        <DxBoxItem :ratio="0" base-size="150">
          <template #default>
            <div class="rect demo-dark">첨부</div>
          </template>
        </DxBoxItem>
        <DxBoxItem :ratio="1">
          <template #default>
            <div>ㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈ</div>
          </template>
        </DxBoxItem>
      </DxBox>
      <DxToolbarItem
        widget="dxButton"
        toolbar="bottom"
        location="after"
        :options="{
          text: 'Send',
          onClick: doSend,
        }"
      ></DxToolbarItem>
      <DxToolbarItem
        widget="dxButton"
        toolbar="bottom"
        location="after"
        :options="{
          text: 'Close',
          onClick: () => {
            isPopupVisible = false;
          },
        }"
      ></DxToolbarItem>
    </DxPopup>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

import { DxButton } from "devextreme-vue/button";
import { DxPopup, DxToolbarItem } from "devextreme-vue/popup";
import { DxBox, DxItem as DxBoxItem } from "devextreme-vue/box";
import { DxForm, DxSimpleItem } from "devextreme-vue/form";
import { DxTextBox } from "devextreme-vue/text-box";
import { DxTextArea } from "devextreme-vue/text-area";
import { DxDataGrid, DxColumn } from "devextreme-vue/data-grid";
import { DxRadioGroup } from "devextreme-vue/radio-group";
import {
  DxHtmlEditor,
  DxToolbar,
  DxMediaResizing,
  DxItem,
} from "devextreme-vue/html-editor";

@Component({
  components: {
    DxButton,
    DxPopup,
    DxToolbarItem,
    DxBox,
    DxBoxItem,
    DxForm,
    DxSimpleItem,
    DxTextBox,
    DxTextArea,
    DxDataGrid,
    DxColumn,
    DxRadioGroup,
    DxHtmlEditor,
    DxToolbar,
    DxMediaResizing,
    DxItem,
  },
})
export default class MailList extends Vue {
  private isPopupVisible = false;
  private subject = "";
  private contents = "";
  private gubun = "";
  private gridData: any[] = [];

  constructor() {
    super();
  }

  public mounted() {
    this.subject = "Mail subject...";
    this.contents = "Rich text...";
    this.gubun = "수신";

    this.gridData = [
      {
        no: 1,
        gubun: "수신",
        name: "홍길동1",
        grade: "차장",
        dept: "전략사업부",
      },
      {
        no: 2,
        gubun: "수신",
        name: "홍길동2",
        grade: "부장",
        dept: "전략사업부",
      },
      {
        no: 3,
        gubun: "참조",
        name: "홍길동3",
        grade: "사원",
        dept: "전략사업부",
      },
      {
        no: 4,
        gubun: "참조",
        name: "홍길동4",
        grade: "대리",
        dept: "전략사업부",
      },
      {
        no: 5,
        gubun: "숨은참조",
        name: "홍길동5",
        grade: "과장",
        dept: "전략사업부",
      },
    ];
  }

  public get dataGrid() {
    return (this.$refs["dataGrid"] as any).instance;
  }

  // public get dataSource() {
  //   return new CustomStore({
  //     key: ["gubun,", "name"],
  //     load: () => this.loadData(),
  //     update: (key, values) => this.saveData(key, values),
  //     remove: (key) => this.removeData(key),
  //   });
  // }

  public get dataSource() {
    return this.gridData;
  }

  public get gubunSource() {
    return ["수신", "참조", "숨은참조"];
  }

  public onPopup(e: any) {
    this.isPopupVisible = true;
  }

  public gubunValueChanged(e: any) {
    const rowKey = this.dataGrid.getSelectedRowKeys();
    if (rowKey.length === 0) return;
    const rowIndex = this.dataGrid.getRowIndexByKey(rowKey[0]);
    this.gridData[rowIndex].gubun = e.value;
  }

  public onDelete(e: any) {
    console.log("onDelete...");
    const rowKey = this.dataGrid.getSelectedRowKeys();
    if (rowKey.length === 0) return;
    const rowIndex = this.dataGrid.getRowIndexByKey(rowKey[0]);
    this.gridData.splice(rowIndex, 1);
  }

  public onUp(e: any) {
    console.log("onUp...");
    const rowKey = this.dataGrid.getSelectedRowKeys();
    if (rowKey.length === 0) return;
    const rowIndex = this.dataGrid.getRowIndexByKey(rowKey[0]);
    console.log("rowIndex ::: ", rowIndex);
    if (rowIndex === 0) return;
    let rowItem = this.gridData[rowIndex];
    this.gridData.splice(rowIndex, 1);
    this.gridData.splice(rowIndex - 1, 0, rowItem);
  }

  public onDown(e: any) {
    console.log("onDown...");
    const rowKey = this.dataGrid.getSelectedRowKeys();
    if (rowKey.length === 0) return;
    const rowIndex = this.dataGrid.getRowIndexByKey(rowKey[0]);
    console.log("rowIndex ::: ", rowIndex);
    if (rowIndex === this.gridData.length - 1) return;
    let rowItem = this.gridData[rowIndex];
    this.gridData.splice(rowIndex, 1);
    this.gridData.splice(rowIndex + 1, 0, rowItem);
  }

  public doSend(e: any) {
    console.log("e >>> ", e);
  }

  // public async loadData() {
  //   console.log("loadData...");
  //   return this.gridData;
  // }

  // public async saveData(key: any, values: any) {
  //   console.log("saveData...");
  //   // const rowIndex = this.dataGrid.getRowIndexByKey(key);
  //   // this.dataGrid.deleteRow(rowIndex);
  // }

  // public async removeData(key: any) {
  //   const rowIndex = this.dataGrid.getRowIndexByKey(key);
  //   const dataSource = this.dataGrid.getDataSource();
  //   dataSource.items().splice(rowIndex, 1);
  //   this.dataGrid.deselectAll();
  // }
}
</script>

<style scoped>
.rect {
  text-align: center;
  padding-top: 10px;
  height: 100%;
}

.demo-light {
  background: rgba(245, 229, 166, 0.5);
}

.demo-dark {
  background: rgba(148, 215, 199, 0.5);
}

.demo-dark.header {
  background: rgba(243, 158, 108, 0.5);
}

.demo-dark.footer {
  background: rgba(123, 155, 207, 0.5);
}
</style>
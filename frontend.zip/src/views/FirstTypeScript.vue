<template>
  <div>
    <DxList :items="items" selection-mode="single" display-expr="text">
      <template #item="{ data }">
        <MyItem :text="data.text"></MyItem>
      </template>
    </DxList>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

import { DxList } from "devextreme-vue/list";

import MyItem from "../components/MyItem.vue";

interface IListItemProps {
  code: string;
  text: string;
}

@Component({
  components: {
    DxList,
    MyItem,
  },
})
export default class FirstTypeScript extends Vue {
  constructor() {
    super();
  }

  public items: IListItemProps[] = [
    { code: "Code-1", text: "Item 1" },
    { code: "Code-2", text: "Item 2" },
    { code: "Code-3", text: "Item 3" },
    { code: "Code-4", text: "Item 4" },
    { code: "Code-5", text: "Item 5" },
  ];
}
</script>
<template>
  <div>Approval list</div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
export default class ApprovalList extends Vue {}
</script>
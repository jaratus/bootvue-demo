<template>
  <div class="about">
    <h1>This is an about page</h1>

    <DxButton :text="title" @click="greeting"></DxButton>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

import { DxButton } from "devextreme-vue/button";

@Component({
  components: {
    DxButton,
  },
})
export default class About extends Vue {
  private title = "Click me";

  public greeting() {
    console.log(this.title);
  }
}
</script>
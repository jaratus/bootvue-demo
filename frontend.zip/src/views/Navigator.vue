<template>
  <div>
    <DxToolbar id="toolbar">
      <DxItem
        widget="dxButton"
        :options="{
          icon: 'menu',
          onClick: () => {
            isDrawerOpen = !isDrawerOpen;
          },
        }"
        location="before"
      ></DxItem>
    </DxToolbar>
    <DxDrawer :opened.sync="isDrawerOpen" reveal-mode="slide" template="navi">
      <template #navi>
        <NavigationList @navigated="navigated"></NavigationList>
      </template>
      <div id="view">
        <router-view></router-view>
      </div>
    </DxDrawer>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

import { DxToolbar, DxItem } from "devextreme-vue/toolbar";
import { DxDrawer } from "devextreme-vue/drawer";

import NavigationList from "../components/NavigationList.vue";

@Component({
  components: {
    DxToolbar,
    DxItem,
    DxDrawer,

    NavigationList,
  },
})
export default class Navigator extends Vue {
  private isDrawerOpen = true;

  public navigated(e: any) {
    console.log("parent navigated...", e);
  }
}
</script>

<style scoped>
/* #toolbar {
  background-color: rgba(191, 191, 191, 0.15);
  padding: 5px 10px;
} */

.dx-toolbar {
  background-color: rgba(191, 191, 191, 0.15);
  padding: 5px 10px;
}

.dx-list-item-icon-container,
.dx-toolbar-before {
  width: 36px;
  padding-right: 0 !important;
  text-align: left;
}

.dx-list-item-content {
  padding-left: 10px !important;
}

.dx-button {
  background-color: rgba(191, 191, 191, -0.15);
  border: none;
}
</style>
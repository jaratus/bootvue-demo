<template>
  <div>SentMail</div>
</template>
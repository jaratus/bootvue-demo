<template>
  <div>Trash</div>
</template>
<template>
  <div>Inbox</div>
</template>